package com.example.menutabs
import android.view.View
import androidx.viewpager2.widget.ViewPager2

class CustomPageTransformer : ViewPager2.PageTransformer {
    override fun transformPage(view: View, position: Float) {
        when {
            position < -1 -> { // Página fuera del lado izquierdo
                view.alpha = 0f
            }
            position <= 1 -> { // Página visible o parcialmente visible
                view.alpha = 1 - Math.abs(position) // Ajusta la transparencia
                view.scaleX = 0.85f + (1 - Math.abs(position)) * 0.15f // Escala en X
                view.scaleY = 0.85f + (1 - Math.abs(position)) * 0.15f // Escala en Y
            }
            else -> { // Página fuera del lado derecho
                view.alpha = 0f
            }
        }
    }
}
