package com.example.menutabs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.example.menutabs.databinding.FragmentTab2Binding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Tab2Fragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class Tab2Fragment : Fragment() {

    private var _binding: FragmentTab2Binding? = null
    private val binding get() = _binding!!

    companion object {
        private const val ARG_OPTION = "option"

        fun newInstance(option: String): Tab2Fragment {
            val fragment = Tab2Fragment()
            val args = Bundle()
            args.putString(ARG_OPTION, option)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTab2Binding.inflate(inflater, container, false)
        val view = binding.root

        // Lista de imágenes (referencias a drawable)
        val images = listOf(
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8,
            R.drawable.image9
        )

        // Configuración del RecyclerView
        binding.galeryrecicler.layoutManager = GridLayoutManager(context, 2) // 2 columnas
        val adapter = GalleryAdapter(requireContext(), images)
        binding.galeryrecicler.adapter = adapter

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null  // Evitar fugas de memoria
    }

}