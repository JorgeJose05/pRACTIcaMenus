package com.example.menulateral

import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencia al NavigationView
        var navigationView = findViewById<NavigationView>(R.id.navigation_view)
        val headerView = navigationView.getHeaderView(0)

        // Configurar Spinner en el encabezado
        val spinner = headerView.findViewById<Spinner>(R.id.header_spinner)

        // Cargar las opciones del Spinner
        val options = resources.getStringArray(R.array.spinner_options)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        spinner.adapter = adapter

        // Inicializa la Toolbar
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // Configura el DrawerLayout
        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)

        // Configura el ActionBarDrawerToggle
        actionBarDrawerToggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.drawer_open,
            R.string.drawer_close
        )
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        // Manejar clics en el NavigationView
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_option1 -> {
                    // Acción para la Opción 1
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.content_frame, OptionFragment.newInstance("Inbox"))
                        .commit()
                }
                R.id.nav_option2 -> {
                    // Acción para la Opción 2
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.content_frame, OptionFragment.newInstance("Outbox"))
                        .commit()
                }
                R.id.nav_option3 -> {
                    // Acción para la Opción 3
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.content_frame, OptionFragment.newInstance("Trash"))
                        .commit()
                }
                R.id.nav_option4 -> {
                    // Acción para la Opción 3
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.content_frame, OptionFragment.newInstance("Spam"))
                        .commit()
                }
            }
            drawerLayout.closeDrawers()
            true
        }
    }
}
