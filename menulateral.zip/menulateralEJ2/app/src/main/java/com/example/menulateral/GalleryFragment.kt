package com.example.menulateral

import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.menulateral.databinding.GalleryFragmentBinding

class GalleryFragment : Fragment() {

    private var _binding: GalleryFragmentBinding? = null
    private val binding get() = _binding!!

    companion object {
        private const val ARG_OPTION = "option"

        fun newInstance(option: String): GalleryFragment {
            val fragment = GalleryFragment()
            val args = Bundle()
            args.putString(ARG_OPTION, option)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = GalleryFragmentBinding.inflate(inflater, container, false)
        val view = binding.root

        // Lista de imágenes (referencias a drawable)
        val images = listOf(
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8,
            R.drawable.image9
        )

        // Configuración del RecyclerView
        binding.galeryrecicler.layoutManager = GridLayoutManager(context, 2) // 2 columnas
        val adapter = GalleryAdapter(requireContext(), images)
        binding.galeryrecicler.adapter = adapter

        return view
    }

    // Manejo de las opciones del menú contextual
    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.option_1 -> {
                val position = item.groupId // Recuperar la posición del elemento seleccionado
                Toast.makeText(requireContext(), "Opción 1 seleccionada en posición $position", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.option_2 -> {
                val position = item.groupId
                Toast.makeText(requireContext(), "Opción 2 seleccionada en posición $position", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.option_3 -> {
                val position = item.groupId
                Toast.makeText(requireContext(), "Opción 2 seleccionada en posición $position", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null  // Evitar fugas de memoria
    }
}
